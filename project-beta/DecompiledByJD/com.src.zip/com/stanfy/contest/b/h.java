package com.stanfy.contest.b;

public class h
  implements Cloneable
{
  private d a;
  private int b;
  private int c;

  public h(int paramInt1, int paramInt2, d paramd)
  {
    this.b = paramInt2;
    this.c = paramInt1;
    this.a = paramd;
  }

  public char a(k paramk)
  {
    return '?';
  }

  public int d()
  {
    return this.b;
  }

  public void a(int paramInt)
  {
    this.b = paramInt;
  }

  public int e()
  {
    return this.c;
  }

  public void b(int paramInt)
  {
    this.c = paramInt;
  }

  protected final h f()
  {
    return ((h)super.clone());
  }

  public final d g()
  {
    return this.a;
  }
}