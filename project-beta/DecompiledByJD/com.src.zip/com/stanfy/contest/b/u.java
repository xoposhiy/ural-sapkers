package com.stanfy.contest.b;

import com.stanfy.contest.c.f;
import com.stanfy.contest.c.g;

final class u
  implements f
{
  public final g a(c paramc)
  {
    return null;
  }
}