package com.stanfy.contest.b;

public final class j extends h
{
  private boolean a = true;

  public j(int paramInt1, int paramInt2, d paramd)
  {
    super(paramInt1, paramInt2, paramd);
  }

  public final boolean a()
  {
    return this.a;
  }

  public final void a(boolean paramBoolean)
  {
    this.a = paramBoolean;
  }
}