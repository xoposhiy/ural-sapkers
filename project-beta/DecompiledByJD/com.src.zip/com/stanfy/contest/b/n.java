package com.stanfy.contest.b;

final class n extends h
{
  n(int paramInt1, int paramInt2, d paramd)
  {
    super(-1, -1, null);
  }

  public final char a(k paramk)
  {
    return '.';
  }
}