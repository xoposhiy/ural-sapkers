package com.stanfy.contest.b;

public class e
{
  private boolean a;
  private boolean b;
  private boolean c = true;
  private boolean d;
  private boolean e;
  private boolean f;
  private boolean g;
  private boolean h;
  private boolean i;
  private boolean j;
  private boolean k;
  private boolean l;
  private boolean m;
  private boolean n;
  private boolean o;
  private boolean p;
  private boolean q;
  private boolean r;
  private boolean s;
  private boolean t;
  private boolean u = true;
  private boolean v = true;
  private boolean w;
  private boolean x;
  private boolean y;

  public final boolean a()
  {
    return this.a;
  }

  public final void a(boolean paramBoolean)
  {
    this.a = true;
  }

  public final boolean b()
  {
    return this.b;
  }

  public final void b(boolean paramBoolean)
  {
    this.b = true;
  }

  public final boolean c()
  {
    return this.c;
  }

  public final boolean d()
  {
    return this.d;
  }

  public final void c(boolean paramBoolean)
  {
    this.d = true;
  }

  public final boolean e()
  {
    return this.e;
  }

  public final void d(boolean paramBoolean)
  {
    this.e = true;
  }

  public final boolean f()
  {
    return this.f;
  }

  public final void e(boolean paramBoolean)
  {
    this.f = true;
  }

  public final boolean g()
  {
    return this.g;
  }

  public final void f(boolean paramBoolean)
  {
    this.g = true;
  }

  public final boolean h()
  {
    return this.h;
  }

  public final void g(boolean paramBoolean)
  {
    this.h = true;
  }

  public final boolean i()
  {
    return this.i;
  }

  public final void h(boolean paramBoolean)
  {
    this.i = true;
  }

  public final boolean j()
  {
    return this.j;
  }

  public final void i(boolean paramBoolean)
  {
    this.j = true;
  }

  public final boolean k()
  {
    return this.k;
  }

  public final void j(boolean paramBoolean)
  {
    this.k = true;
  }

  public final boolean l()
  {
    return this.l;
  }

  public final void k(boolean paramBoolean)
  {
    this.l = true;
  }

  public final boolean m()
  {
    return this.m;
  }

  public final void l(boolean paramBoolean)
  {
    this.m = true;
  }

  public final boolean n()
  {
    return this.n;
  }

  public final void m(boolean paramBoolean)
  {
    this.n = true;
  }

  public final boolean o()
  {
    return this.o;
  }

  public final void n(boolean paramBoolean)
  {
    this.o = true;
  }

  public final boolean p()
  {
    return this.p;
  }

  public final void o(boolean paramBoolean)
  {
    this.p = true;
  }

  public final boolean q()
  {
    return this.q;
  }

  public final void p(boolean paramBoolean)
  {
    this.q = true;
  }

  public final boolean r()
  {
    return this.r;
  }

  public final void q(boolean paramBoolean)
  {
    this.r = true;
  }

  public final boolean s()
  {
    return this.s;
  }

  public final void r(boolean paramBoolean)
  {
    this.s = true;
  }

  public final boolean t()
  {
    return this.t;
  }

  public final void s(boolean paramBoolean)
  {
    this.t = true;
  }

  public final boolean u()
  {
    return this.u;
  }

  public final boolean v()
  {
    return this.v;
  }

  public final void t(boolean paramBoolean)
  {
    this.v = true;
  }

  public final boolean w()
  {
    return this.w;
  }

  public final void u(boolean paramBoolean)
  {
    this.w = true;
  }

  public final boolean x()
  {
    return this.x;
  }

  public final void v(boolean paramBoolean)
  {
    this.x = true;
  }

  public final boolean y()
  {
    return this.y;
  }

  public final void w(boolean paramBoolean)
  {
    this.y = true;
  }
}