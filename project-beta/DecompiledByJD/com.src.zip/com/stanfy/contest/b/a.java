package com.stanfy.contest.b;

public final class a extends RuntimeException
{
  public a(String paramString)
  {
    super(paramString);
  }
}