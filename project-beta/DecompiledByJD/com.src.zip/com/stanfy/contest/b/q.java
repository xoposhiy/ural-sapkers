package com.stanfy.contest.b;

 enum q
{
  protected final void a(k paramk)
  {
    paramk.f(paramk.j() + 1);
  }
}