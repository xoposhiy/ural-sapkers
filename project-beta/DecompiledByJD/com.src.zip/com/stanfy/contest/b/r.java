package com.stanfy.contest.b;

 enum r
{
  protected final void a(k paramk)
  {
    paramk.g(paramk.k() + 1);
  }
}