package com.stanfy.contest.b;

public final class t extends h
{
  public t(int paramInt1, int paramInt2, d paramd)
  {
    super(paramInt1, paramInt2, paramd);
  }

  public final char a(k paramk)
  {
    if ((paramk != null) && (!(paramk.u().l())))
      return '?';
    return 'X';
  }
}