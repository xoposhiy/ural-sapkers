package com.stanfy.contest.b;

 enum p
{
  protected final void a(k paramk)
  {
    paramk.e(paramk.i() + 1);
  }
}