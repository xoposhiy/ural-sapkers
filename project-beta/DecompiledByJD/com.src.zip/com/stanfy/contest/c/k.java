package com.stanfy.contest.c;

public enum k
{
  a, b;

  private String c;
}