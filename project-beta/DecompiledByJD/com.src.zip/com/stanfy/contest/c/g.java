package com.stanfy.contest.c;

import com.stanfy.contest.b.k;

public abstract interface g
{
  public abstract String a(k paramk);
}