package com.stanfy.contest.c;

import com.stanfy.contest.b.c;

public abstract interface f
{
  public abstract g a(c paramc);
}