package com.stanfy.contest.c;

import com.stanfy.contest.b.k;

public final class h
  implements g
{
  private h a = null;
  private g b = null;

  public h(g paramg)
  {
    this.b = paramg;
  }

  public final h a(g paramg)
  {
    (paramg = new h(paramg)).a = this;
    return paramg;
  }

  public final String a(k paramk)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (this.a != null)
      localStringBuilder.append(this.a.a(paramk));
    if (this.b != null)
      if (((this = this.b.a(paramk)) != null) && (!(isEmpty())))
      {
        if (localStringBuilder.length() > 0)
          localStringBuilder.append(",");
        localStringBuilder.append(this);
      }
    return localStringBuilder.toString();
  }
}