package com.stanfy.contest;

import com.stanfy.contest.b.c;
import java.net.Socket;

public class a
{
  public void a(g paramg, Socket paramSocket)
  {
    g.a(paramSocket, new com.stanfy.contest.a.b.f(this.a).a(this.a.b(0)));
  }
}