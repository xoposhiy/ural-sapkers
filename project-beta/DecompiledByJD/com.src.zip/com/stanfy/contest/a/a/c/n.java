package com.stanfy.contest.a.a.c;

import com.stanfy.contest.a.a.u;

final class n extends o
{
  n(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    am.e(paramam).b("statusExit");
    return "QUIT";
  }

  public final String a()
  {
    return "Quits from Fifth interpreter.. Doesn't changing stack.\r\n All types are allowed : <> QUIT -> <>";
  }
}