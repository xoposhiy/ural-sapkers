package com.stanfy.contest.a.a;

import com.stanfy.contest.a.a.a.b.a;
import com.stanfy.contest.a.a.b.c;

final class e extends a
{
  e(h paramh, Class paramClass)
  {
    super(paramClass);
  }

  public final String b(c paramc)
  {
    h.a(this = (h)paramc, true);
    h.b(this, true);
    return "DNA process state with deep analisys has been approved.";
  }
}