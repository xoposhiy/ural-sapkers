package com.stanfy.contest.a.a.c;

final class e extends o
{
  e(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    return "USAGE PREFIX";
  }

  public final String a()
  {
    return "Outputs usage of DEFINITION. Doesn't changing stack.\r\n Only registered definitions are allowed : ?<DEFINITION_NAME>";
  }
}