package com.stanfy.contest.a.a.c;

import java.util.ArrayList;

public final class an extends o
{
  private ArrayList a = new ArrayList();
  private ArrayList b = new ArrayList();
  private ArrayList c = new ArrayList();

  public an(String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    Object localObject = null;
    if (this.c.size() > 0)
    {
      paramam = this.a.toString();
      this = "ENDIF";
      throw new y("Expecting '" + this + "', but " + paramam + " found.");
    }
    int k = 0;
    while (true)
    {
      label172: label219: int j;
      while (true)
      {
        ao localao1;
        int l;
        ao localao2;
        while (true)
        {
          while (true)
          {
            String str;
            if (k >= this.a.size())
              break label287;
            if (!((str = (String)this.a.get(k)).matches("IFTHEN\\d+")))
              break label219;
            int i = Integer.valueOf(str.substring("IFTHEN".length())).intValue();
            if ((l = am.a(paramam.b("DROP")).intValue()) != 0)
              break label172;
            if (!((localao1 = (ao)this.b.get(i)).b()))
              break;
            k = localao1.a();
          }
          k = localao1.c();
        }
        if (l != -1)
        {
          this = String.valueOf(l);
          throw new y("Data must be boolean (0 = FALSE), (-1 = TRUE)(" + this + ").");
        }
        break label281:
        if (!(localao1.matches("ELSE\\d+")))
          break;
        j = Integer.valueOf(localao1.substring("ELSE".length())).intValue();
        k = (localao2 = (ao)this.b.get(j)).c();
      }
      if (!(j.matches("ENDIF\\d+")))
        localObject = paramam.b(j);
      label281: ++k;
    }
    label287: return localObject;
  }

  public final void a(String paramString)
  {
    if (paramString.equals("IFTHEN"))
    {
      (this = this).a.add("IFTHEN" + this.b.size());
      paramString = new ao(this.a.size());
      this.b.add(paramString);
      this.c.add(Integer.valueOf(this.b.size() - 1));
      return;
    }
    if (paramString.equals("ELSE"))
    {
      if ((this = this).c.size() == 0)
        throw y.c("ELSE");
      paramString = ((Integer)this.c.get(this.c.size() - 1)).intValue();
      this.a.add("ELSE" + paramString);
      ((ao)this.b.get(paramString)).a(this.a.size());
      return;
    }
    if (paramString.equals("ENDIF"))
    {
      if ((this = this).c.size() == 0)
        throw y.c("ENDIF");
      paramString = ((Integer)this.c.get(this.c.size() - 1)).intValue();
      this.a.add("ENDIF" + paramString);
      ((ao)this.b.get(paramString)).b(this.a.size() - 1);
      this.c.remove(this.c.size() - 1);
      return;
    }
    this.a.add(paramString);
  }

  public final String a()
  {
    return "USER-DEFINED WORD : " + this.a.toString();
  }
}