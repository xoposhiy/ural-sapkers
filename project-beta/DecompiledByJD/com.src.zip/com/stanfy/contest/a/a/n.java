package com.stanfy.contest.a.a;

import com.stanfy.contest.a.a.a.b.a;
import com.stanfy.contest.a.a.b.c;

final class n extends a
{
  n(d paramd, Class paramClass)
  {
    super(paramClass);
  }

  public final String b(c paramc)
  {
    d.b(this = (d)paramc, true);
    return "Sattelite control functioning has been approved.";
  }
}