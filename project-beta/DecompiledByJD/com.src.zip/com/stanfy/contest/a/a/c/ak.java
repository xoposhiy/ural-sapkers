package com.stanfy.contest.a.a.c;

import java.util.Stack;

final class ak extends o
{
  ak(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    this = String.valueOf(this = (char)(this = am.a(am.a(paramam).pop()).intValue()));
    am.a(paramam).push(this);
    return this;
  }

  public final String a()
  {
    return "Gets Integer, converts it to char value and puts it at top of stack\r\n Only Integers are allowed : <INTEGER> CHR -> <STRING> \r\n EXAMPLE: 115 CHR . OUTPUT:s\r\n          97 ORD . OUTPUT:a";
  }
}