package com.stanfy.contest.a.a.a.b;

import com.stanfy.contest.a.a.b.c;

public abstract class a
{
  private Class a;

  public String a(c paramc)
  {
    if (paramc.getClass() == this.a)
      return b(paramc);
    return "";
  }

  public Class a()
  {
    return this.a;
  }

  public a(Class paramClass)
  {
    this.a = paramClass;
  }

  public abstract String b(c paramc);
}