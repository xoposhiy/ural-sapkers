package com.stanfy.contest.a.a.b;

public abstract interface c
{
  public abstract void a(String paramString);

  public abstract void b(b paramb);

  public abstract void a(b paramb);
}