package com.stanfy.contest.a.a.a.a;

import com.stanfy.contest.b.e;

public abstract class n
{
  public abstract String a(e parame);

  public abstract String a();
}