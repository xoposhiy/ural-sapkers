package com.stanfy.contest.a.a.b;

public abstract interface d
{
  public abstract void b(c paramc, String paramString);
}