package com.stanfy.contest.a.a.d;

import java.util.Vector;

public final class b
{
  private int[][] a = new int[8][8];

  public b()
  {
    a();
  }

  public final void a()
  {
    for (int i = 0; i < 8; ++i)
      for (int j = 0; j < 8; ++j)
        if (i % 2 == j % 2)
          if (i < 3)
            this.a[i][j] = 3;
          else if (i > 4)
            this.a[i][j] = 1;
          else
            this.a[i][j] = 0;
        else
          this.a[i][j] = 0;
  }

  public final int a(int paramInt1, int paramInt2)
  {
    return this.a[paramInt1][paramInt2];
  }

  public final void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.a[paramInt3][paramInt4] = this.a[paramInt1][paramInt2];
    this.a[paramInt1][paramInt2] = 0;
    if ((paramInt1 - paramInt3 == 2) || (paramInt1 - paramInt3 == -2))
    {
      paramInt1 = (paramInt1 + paramInt3) / 2;
      paramInt2 = (paramInt2 + paramInt4) / 2;
      this.a[paramInt1][paramInt2] = 0;
    }
    if ((paramInt3 == 0) && (this.a[paramInt3][paramInt4] == 1))
      this.a[paramInt3][paramInt4] = 2;
    if ((paramInt3 == 7) && (this.a[paramInt3][paramInt4] == 3))
      this.a[paramInt3][paramInt4] = 4;
  }

  public final a[] a(int paramInt)
  {
    if ((paramInt != 1) && (paramInt != 3))
      return null;
    int i = (paramInt == 1) ? 2 : 4;
    Vector localVector = new Vector();
    for (int j = 0; j < 8; ++j)
      for (k = 0; k < 8; ++k)
        if ((this.a[j][k] == paramInt) || (this.a[j][k] == i))
        {
          if (a(paramInt, j, k, j + 1, k + 1, j + 2, k + 2))
            localVector.addElement(new a(j, k, j + 2, k + 2));
          if (a(paramInt, j, k, j - 1, k + 1, j - 2, k + 2))
            localVector.addElement(new a(j, k, j - 2, k + 2));
          if (a(paramInt, j, k, j + 1, k - 1, j + 2, k - 2))
            localVector.addElement(new a(j, k, j + 2, k - 2));
          if (a(paramInt, j, k, j - 1, k - 1, j - 2, k - 2))
            localVector.addElement(new a(j, k, j - 2, k - 2));
        }
    if (localVector.size() == 0)
      for (j = 0; j < 8; ++j)
        for (k = 0; k < 8; ++k)
          if ((this.a[j][k] == paramInt) || (this.a[j][k] == i))
          {
            if (a(paramInt, j, k, j + 1, k + 1))
              localVector.addElement(new a(j, k, j + 1, k + 1));
            if (a(paramInt, j, k, j - 1, k + 1))
              localVector.addElement(new a(j, k, j - 1, k + 1));
            if (a(paramInt, j, k, j + 1, k - 1))
              localVector.addElement(new a(j, k, j + 1, k - 1));
            if (a(paramInt, j, k, j - 1, k - 1))
              localVector.addElement(new a(j, k, j - 1, k - 1));
          }
    if (localVector.size() == 0)
      return null;
    a[] arrayOfa = new a[localVector.size()];
    for (int k = 0; k < localVector.size(); ++k)
      arrayOfa[k] = ((a)localVector.elementAt(k));
    return arrayOfa;
  }

  public final a[] a(int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramInt1 != 1) && (paramInt1 != 3))
      return null;
    int i = (paramInt1 == 1) ? 2 : 4;
    Vector localVector = new Vector();
    if ((this.a[paramInt2][paramInt3] == paramInt1) || (this.a[paramInt2][paramInt3] == i))
    {
      if (a(paramInt1, paramInt2, paramInt3, paramInt2 + 1, paramInt3 + 1, paramInt2 + 2, paramInt3 + 2))
        localVector.addElement(new a(paramInt2, paramInt3, paramInt2 + 2, paramInt3 + 2));
      if (a(paramInt1, paramInt2, paramInt3, paramInt2 - 1, paramInt3 + 1, paramInt2 - 2, paramInt3 + 2))
        localVector.addElement(new a(paramInt2, paramInt3, paramInt2 - 2, paramInt3 + 2));
      if (a(paramInt1, paramInt2, paramInt3, paramInt2 + 1, paramInt3 - 1, paramInt2 + 2, paramInt3 - 2))
        localVector.addElement(new a(paramInt2, paramInt3, paramInt2 + 2, paramInt3 - 2));
      if (a(paramInt1, paramInt2, paramInt3, paramInt2 - 1, paramInt3 - 1, paramInt2 - 2, paramInt3 - 2))
        localVector.addElement(new a(paramInt2, paramInt3, paramInt2 - 2, paramInt3 - 2));
    }
    if (localVector.size() == 0)
      return null;
    this = new a[localVector.size()];
    for (paramInt1 = 0; paramInt1 < localVector.size(); ++paramInt1)
      this[paramInt1] = ((a)localVector.elementAt(paramInt1));
    return this;
  }

  private boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    if ((paramInt6 < 0) || (paramInt6 >= 8) || (paramInt7 < 0) || (paramInt7 >= 8))
      return false;
    if (this.a[paramInt6][paramInt7] != 0)
      return false;
    if (paramInt1 == 1)
    {
      if ((this.a[paramInt2][paramInt3] == 1) && (paramInt6 > paramInt2))
        return false;
      return ((this.a[paramInt4][paramInt5] == 3) || (this.a[paramInt4][paramInt5] == 4));
    }
    if ((this.a[paramInt2][paramInt3] == 3) && (paramInt6 < paramInt2))
      return false;
    return ((this.a[paramInt4][paramInt5] == 1) || (this.a[paramInt4][paramInt5] == 2));
  }

  private boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if ((paramInt4 < 0) || (paramInt4 >= 8) || (paramInt5 < 0) || (paramInt5 >= 8))
      return false;
    if (this.a[paramInt4][paramInt5] != 0)
      return false;
    if (paramInt1 == 1)
      return ((this.a[paramInt2][paramInt3] != 1) || (paramInt4 <= paramInt2));
    return ((this.a[paramInt2][paramInt3] != 3) || (paramInt4 >= paramInt2));
  }
}