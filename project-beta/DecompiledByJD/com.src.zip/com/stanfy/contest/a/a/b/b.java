package com.stanfy.contest.a.a.b;

import com.stanfy.contest.b.k;

public abstract interface b extends d
{
  public abstract void a(c paramc, String paramString);

  public abstract k a();

  public abstract c a(Class paramClass);
}