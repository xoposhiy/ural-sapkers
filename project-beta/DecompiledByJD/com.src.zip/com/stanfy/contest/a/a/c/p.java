package com.stanfy.contest.a.a.c;

import java.util.Stack;

final class p extends o
{
  p(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    return am.a(this.a).pop();
  }

  public final String a()
  {
    return "Removes object from top of stack\r\n All types are allowed : <OBJ1> DUP -> <>\r\n EXAMPLE: 3 2 1 DROP DROP . OUTPUT:3";
  }
}