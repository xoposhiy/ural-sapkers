package com.stanfy.contest.a.a.c;

final class j extends o
{
  j(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    return "ENDIF";
  }

  public final String a()
  {
    return "Part of LOGICAL BRANCH creation. \r\nFORMAT  :  (EXPRESSION)IFTHEN <LIST OF COMMANDS ON TRUE> [ELSE <LIST OF COMMANDS ON FALSE> ] ENDIF\r\nEXAMPLE :  @A @B > IFTHEN  @A ->C ELSE @B ->C ENDIF ; Calculates max and puts it in variable C\r\n";
  }
}