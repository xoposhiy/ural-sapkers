package com.stanfy.contest.a.a.c;

import java.util.Stack;

final class ag extends o
{
  ag(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    this = String.valueOf(this = am.a(am.a(paramam).pop()).intValue());
    am.a(paramam).push(this);
    return this;
  }

  public final String a()
  {
    return "Converts Int to String, and puts result at top of stack\r\n Only Int is alllowed : <INT> INTTOSTR -> <STRING> \r\n EXAMPLE: 42 INTTOSTR . OUTPUT:42";
  }
}