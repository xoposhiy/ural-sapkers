package com.stanfy.contest.a.a;

import com.stanfy.contest.a.a.a.b.a;
import com.stanfy.contest.a.a.b.c;

final class m extends a
{
  m(d paramd, Class paramClass)
  {
    super(paramClass);
  }

  public final String b(c paramc)
  {
    d.a(this = (d)paramc, true);
    return "Sattelite control virus erasing has been approved.";
  }
}