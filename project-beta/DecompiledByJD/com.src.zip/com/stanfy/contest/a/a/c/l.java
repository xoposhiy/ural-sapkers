package com.stanfy.contest.a.a.c;

import java.util.Stack;

final class l extends o
{
  l(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    am.a(paramam).clear();
    return "CLEAR";
  }

  public final String a()
  {
    return "Clears current stack. \r\nFORMAT  : CLEAR \r\nEXAMPLE : 2 3 4 CLEAR . ; puts 2 ints into stack, clears it, and gets top of stack. Result - stack is clear message.\r\n";
  }
}