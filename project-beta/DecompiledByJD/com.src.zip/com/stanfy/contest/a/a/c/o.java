package com.stanfy.contest.a.a.c;

public abstract class o
  implements Comparable
{
  private String a;

  public o(String paramString)
  {
    this.a = paramString;
  }

  public abstract Object a(am paramam);

  public abstract String a();

  public final int hashCode()
  {
    if (this.a == null)
      return super.hashCode();
    return this.a.hashCode();
  }

  public final String toString()
  {
    return this.a;
  }

  public final String b()
  {
    return this.a;
  }
}