package com.stanfy.contest.a.a;

import com.stanfy.contest.a.a.a.b.a;
import com.stanfy.contest.a.a.b.c;

final class g extends a
{
  g(k paramk, Class paramClass)
  {
    super(paramClass);
  }

  public final String b(c paramc)
  {
    k.a(this = (k)paramc, true);
    return "Engine control access granted.";
  }
}