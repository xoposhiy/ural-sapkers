package com.stanfy.contest.a.a.c;

import java.util.Stack;

final class t extends o
{
  t(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    this = am.a(am.a(paramam).pop()).intValue();
    t localt = am.a(am.a(paramam).pop()).intValue();
    am.a(paramam).push(Integer.valueOf(this * localt));
    return Integer.valueOf(this * localt);
  }

  public final String a()
  {
    return "Multiplies two operands at top of stack, returns result to top of stack\r\n Only Ints are allowed : <INT> <INT> * -> <INT>\r\n EXAMPLE: 3 2 * . OUTPUT:6\r\n          0 3 * . OUTPUT:0";
  }
}