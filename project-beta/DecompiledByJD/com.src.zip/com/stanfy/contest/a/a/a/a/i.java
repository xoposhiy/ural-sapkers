package com.stanfy.contest.a.a.a.a;

import com.stanfy.contest.b.e;

public class i extends n
{
  public final String a(e parame)
  {
    this = (parame.f()) ? "re" : "";
    parame.e(true);
    return "Lexical interpreter was successfully " + this + "configured";
  }

  public final String a()
  {
    return "nAtyB40emoaUDb1iBrKF";
  }
}