package com.stanfy.contest.a.a.a.a;

import com.stanfy.contest.b.e;

public class b extends n
{
  public final String a(e parame)
  {
    return "You have earned 20 points. You are a CHEATER!!! Bad guy! But playing games, I too! ;) Try another passwords.";
  }

  public final String a()
  {
    return "tHcrh5hB6L05GR2Bjvey";
  }
}