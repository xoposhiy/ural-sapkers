package com.stanfy.contest.a.a.c;

final class m extends o
{
  m(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    paramam.a();
    return "RESET";
  }

  public final String a()
  {
    return "Clears current stack. And removes user words\r\nFORMAT  : RESET \r\n";
  }
}