package com.stanfy.contest.a.a.c;

public final class ao
{
  private int a = -1;
  private int b = -1;

  public final int a()
  {
    return this.a;
  }

  public final void a(int paramInt)
  {
    this.a = paramInt;
  }

  public final boolean b()
  {
    return (this.a != -1);
  }

  public final int c()
  {
    return this.b;
  }

  public final void b(int paramInt)
  {
    this.b = paramInt;
  }
}