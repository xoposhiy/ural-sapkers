package com.stanfy.contest.a.a;

import com.stanfy.contest.a.a.a.b.a;
import com.stanfy.contest.a.a.b.c;

final class f extends a
{
  f(h paramh, Class paramClass)
  {
    super(paramClass);
  }

  public final String b(c paramc)
  {
    h.b(this = (h)paramc, true);
    return "DNA process state has been approved.";
  }
}