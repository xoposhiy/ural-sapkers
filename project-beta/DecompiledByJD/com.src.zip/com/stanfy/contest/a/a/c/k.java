package com.stanfy.contest.a.a.c;

final class k extends o
{
  k(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    return "ELSE";
  }

  public final String a()
  {
    return "Part of LOGICAL BRANCH creation. \r\nFORMAT  :  (EXPRESSION)IFTHEN <LIST OF COMMANDS ON TRUE> [ELSE <LIST OF COMMANDS ON FALSE> ] ENDIF\r\nEXAMPLE :  @A @B > IFTHEN  @A ->C ELSE @B ->C ENDIF ; Calculates max and puts it in variable C\r\n";
  }
}