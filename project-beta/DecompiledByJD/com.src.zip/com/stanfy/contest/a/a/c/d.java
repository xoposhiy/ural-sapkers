package com.stanfy.contest.a.a.c;

final class d extends o
{
  d(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    this.a.d("\r\n");
    this.a.d(" == 'FIFTH' INTERPRETER == \r\n");
    this.a.d(" Fifth is stack-based programming language.\r\n");
    this.a.d(" It relies on exlicit use of data stack and postfix notation, so operators are placed after operands. \r\n");
    this.a.d(" Extending the compiler reques writing a new word (input '?DEFINITION;' to get more information)\r\n");
    this.a.d(" To see all registered defitions, input 'WORDS;'\r\n");
    this.a.d(" To get info about definition, input '?<DEFITION_NAME>;'\r\n");
    this.a.d(" \r\n");
    this.a.d(" EXAMPLE : ");
    this.a.d("     5 3 4 + * .  ;   Calculates (4 + 3) * 5.  '.' outputs result(top of stack)\r\n");
    this.a.d("     : MULBY5 5 * // \r\n");
    this.a.d("     2 MULBY5 . ;   Adds definition MULBY5 and Calculates 2 * 5. \r\n>");
    return "'FIFTH' HELP";
  }

  public final String a()
  {
    return "Outputs Help. Doesn't changing stack.\r\n All types are allowed : <> HELP -> <>";
  }
}