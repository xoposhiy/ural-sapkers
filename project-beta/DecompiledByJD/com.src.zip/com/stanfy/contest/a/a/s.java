package com.stanfy.contest.a.a;

import com.stanfy.contest.a.a.a.b.a;
import com.stanfy.contest.a.a.b.c;

final class s extends a
{
  s(j paramj, Class paramClass)
  {
    super(paramClass);
  }

  public final String b(c paramc)
  {
    j.b(this = (j)paramc, true);
    return "NUMERAL SYSTEMS TRANSLATE PROBLEM - solved";
  }
}