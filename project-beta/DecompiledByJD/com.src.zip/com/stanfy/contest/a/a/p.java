package com.stanfy.contest.a.a;

import com.stanfy.contest.a.a.a.b.a;
import com.stanfy.contest.a.a.b.c;

final class p extends a
{
  p(i parami, Class paramClass)
  {
    super(paramClass);
  }

  public final String b(c paramc)
  {
    i.a(this = (i)paramc, true);
    return "Lexical interpreter is turned on.";
  }
}