package com.stanfy.contest.a.a.c;

final class i extends o
{
  i(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    return "SAVE_PREFIX";
  }

  public final String a()
  {
    return "Save-to-variable prefix. Saves data at top of stack to specified variable\r\nFORMAT  : ->VARIABLE \r\nEXAMPLE : 3 ->C  ; puts 3 in variable C\r\n";
  }
}