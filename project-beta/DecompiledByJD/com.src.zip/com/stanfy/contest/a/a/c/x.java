package com.stanfy.contest.a.a.c;

import java.util.Stack;

final class x extends o
{
  x(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    if ((this = am.a(paramam).pop()) instanceof String)
    {
      this = (String)this;
      String str = am.b(am.a(paramam).pop());
      am.a(paramam).push(str + this);
      return str + this;
    }
    this = am.a(this).intValue();
    x localx = am.a(am.a(paramam).pop()).intValue();
    am.a(paramam).push(Integer.valueOf(this + localx));
    return Integer.valueOf(this + this);
  }

  public final String a()
  {
    return "Adds two operands at top of stack, returns result to top of stack\r\n Strings or Ints are allowed : <INT> <INT> + -> <INT>, <STRING> <STRING> -> + <STRING>\r\n EXAMPLE: 3 2 + . OUTPUT:5\r\n          'a' 'b' +. OUTPUT:ab";
  }
}