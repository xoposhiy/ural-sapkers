package com.stanfy.contest.a.a.a.a;

import com.stanfy.contest.b.e;

public class a extends n
{
  public final String a(e parame)
  {
    this = ((parame.g()) && (parame.i())) ? "re" : "";
    parame.f(true);
    parame.h(true);
    return "Sattelite connection was successfully " + this + "configured.";
  }

  public final String a()
  {
    return "99qzIHgvjcqNURGGDXI4";
  }
}