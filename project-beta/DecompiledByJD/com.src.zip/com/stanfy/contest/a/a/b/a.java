package com.stanfy.contest.a.a.b;

import com.stanfy.contest.b.k;

public abstract interface a extends c
{
  public abstract void a(k paramk, String paramString);
}