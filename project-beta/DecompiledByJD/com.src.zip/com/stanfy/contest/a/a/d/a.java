package com.stanfy.contest.a.a.d;

public final class a
{
  private int a;
  private int b;
  private int c;
  private int d;

  public a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = paramInt1;
    (paramInt1 = this).a = i;
    i = paramInt2;
    (paramInt1 = this).b = i;
    i = paramInt3;
    (paramInt1 = this).c = i;
    i = paramInt4;
    (paramInt1 = this).d = i;
  }

  public final int a()
  {
    return this.a;
  }

  public final int b()
  {
    return this.b;
  }

  public final int c()
  {
    return this.c;
  }

  public final int d()
  {
    return this.d;
  }
}