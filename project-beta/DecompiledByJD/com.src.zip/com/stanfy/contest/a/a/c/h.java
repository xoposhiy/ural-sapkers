package com.stanfy.contest.a.a.c;

final class h extends o
{
  h(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    return "LOAD_PREFIX";
  }

  public final String a()
  {
    return "Load-from-variable prefix. Gets data from variable and puts it at top of stack\r\nFORMAT  : @VARIABLE \r\nEXAMPLE : 3 ->C @C @C + ->C ; puts 3 in variable C, then gets it two times, calculates sum, and puts it back in C variable.\r\n";
  }
}