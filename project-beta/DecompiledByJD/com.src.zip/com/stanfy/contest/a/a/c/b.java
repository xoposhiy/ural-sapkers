package com.stanfy.contest.a.a.c;

final class b extends o
{
  b(am paramam, String paramString)
  {
    super(paramString);
  }

  public final Object a(am paramam)
  {
    return "Definition prefix";
  }

  public final String a()
  {
    return "Part of DEFINITION creation. Registers definition. \r\nFORMAT  :  : <LIST OF COMMANDS> //\r\nEXAMPLE :  : FACTORIAL DUP =0 IFTHEN DROP 1 ELSE DUP 1 - FACTORIAL * ENDIF //\r\n            5 FACTORIAL . ;  outputs 120 ";
  }
}