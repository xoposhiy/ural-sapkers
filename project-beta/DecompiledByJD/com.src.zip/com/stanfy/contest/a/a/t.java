package com.stanfy.contest.a.a;

import com.stanfy.contest.a.a.a.b.a;
import com.stanfy.contest.a.a.b.c;

final class t extends a
{
  t(j paramj, Class paramClass)
  {
    super(paramClass);
  }

  public final String b(c paramc)
  {
    j.a(this = (j)paramc, true);
    return "MOVING OBJECT IDENTIFICATION PROBLEM - solved";
  }
}