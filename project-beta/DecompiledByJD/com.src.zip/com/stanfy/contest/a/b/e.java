package com.stanfy.contest.a.b;

import com.stanfy.contest.b.c;
import com.stanfy.contest.b.k;
import com.stanfy.contest.b.v;
import com.stanfy.contest.c.g;
import java.util.Iterator;
import java.util.List;

public final class e
  implements b
{
  private c a;
  private g b;

  public e(c paramc, g paramg)
  {
    this.b = paramg;
    this.a = paramc;
  }

  private String b(k paramk)
  {
    com.stanfy.contest.b.e locale;
    if (((locale = (paramk == null) ? null : paramk.u()) != null) && (!(locale.f())))
      return "?";
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = (this = this.a.e()).iterator();
    while (localIterator.hasNext())
    {
      k localk = (k)localIterator.next();
      localStringBuilder.append('P').append(localk.b()).append(" ");
      if (!(localk.m()))
      {
        localStringBuilder.append("dead");
      }
      else
      {
        Object localObject = "? ?";
        if ((paramk == null) || ((localk == paramk) && (locale.i())) || ((localk != paramk) && (locale.g())))
        {
          if (paramk != null)
            if (localk == paramk)
              if (!(locale.j()))
                break label208;
            else
              if (!(locale.h()))
                break label208;
          localObject = localk.c() + " " + localk.h();
          break label241:
          label208: localObject = localk.d() + " " + localk.e();
        }
        label241: localStringBuilder.append(((String)localObject) + " " + (((paramk == null) || (locale.t())) ? Integer.valueOf(localk.k() - localk.l()) : "?") + " " + (((paramk == null) || (locale.s())) ? Integer.valueOf(localk.j()) : "?") + " " + (((paramk == null) || (locale.r())) ? Integer.valueOf(localk.i()) : "?"));
        if ((paramk == null) || ((localk.s()) && (locale.q())))
        {
          if (paramk != null)
          {
            localObject = locale;
          }
          else
          {
            localStringBuilder.append(" ").append(localk.t());
            break label422:
          }
          localStringBuilder.append(" ").append('i');
        }
      }
      if (localk != get(size() - 1))
        label422: localStringBuilder.append(',');
    }
    return ((String)localStringBuilder.toString());
  }

  public final String a(k paramk)
  {
    com.stanfy.contest.b.e locale = (paramk == null) ? null : paramk.u();
    k localk = paramk;
    e locale1 = this;
    localk = paramk;
    locale1 = this;
    if ((locale == null) || (locale.b()));
    return (((localk == null) || (localk.u().e())) ? "T" + locale1.a.b().a() : "?") + "&" + b(paramk) + "&" + locale1.b.a(localk) + ((this.a.c() > 0) ? "" : (locale1 = this) ? "&" + new StringBuilder().append("d ").append(locale1.a.c()).toString() : "") + ";";
  }
}