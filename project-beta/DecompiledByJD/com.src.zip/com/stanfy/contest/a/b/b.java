package com.stanfy.contest.a.b;

import com.stanfy.contest.b.k;

public abstract interface b
{
  public abstract String a(k paramk);
}