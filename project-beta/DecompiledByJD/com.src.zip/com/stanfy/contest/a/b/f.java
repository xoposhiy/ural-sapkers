package com.stanfy.contest.a.b;

import com.stanfy.contest.b.c;
import com.stanfy.contest.b.k;

public final class f
  implements b
{
  private c a;

  public f(c paramc)
  {
    this.a = paramc;
  }

  public final String a(k paramk)
  {
    int i = (paramk == null) ? 2147483647 : paramk.b();
    StringBuilder localStringBuilder = new StringBuilder();
    paramk = paramk;
    localStringBuilder.append("PID").append(i).append("&").append((this = this.a).a(false, paramk)).append(";");
    return localStringBuilder.toString();
  }
}