package com.stanfy.contest.a.b;

import com.stanfy.contest.b.e;
import com.stanfy.contest.b.k;

public final class c
  implements b
{
  private int a;
  private com.stanfy.contest.b.c b;

  public c(int paramInt, com.stanfy.contest.b.c paramc)
  {
    this.a = paramInt;
    this.b = paramc;
  }

  public final String a(k paramk)
  {
    e locale = (paramk == null) ? null : paramk.u();
    if ((paramk == null) || (locale.a()))
      return "START" + this.a + "&" + this.b.a(false, paramk) + ";";
    return null;
  }
}