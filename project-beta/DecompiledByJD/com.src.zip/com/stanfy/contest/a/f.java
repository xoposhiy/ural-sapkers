package com.stanfy.contest.a;

public abstract interface f
{
  public abstract void i();
}