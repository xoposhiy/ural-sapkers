
  TightVNC version 1.3.10
  Binary distribution for Windows platforms

======================================================================

This distribution is based on the standard VNC source and includes new
TightVNC-specific features and fixes, such as additional low-bandwidth
optimizations, major GUI improvements, file transfers, and more.

Executable files included in the release:

   Complete TightVNC server:  winvnc.exe, VNCHooks.dll
   TightVNC Viewer:           vncviewer.exe

TightVNC is available under the terms of the GNU General Public
License (GPL), inclided in the file LICENCE.txt. You can freely use
the software for any legal purpose, but we're asking for donations to
the TightVNC project from commercial users, as well as from motivated
individuals, who like the software. You can donate any amount of your
choice:

   http://www.tightvnc.com/donate.html

Your support ensures we can add more new features and fix more bugs,
making TightVNC a better software for you. Thank you in advance!

Please visit the project homepage at the following URL for more info:

   http://www.tightvnc.com/

